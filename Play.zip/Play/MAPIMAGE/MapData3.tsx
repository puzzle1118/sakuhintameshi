<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="MapData3" tilewidth="32" tileheight="32" tilecount="400" columns="20">
 <image source="MapData3.png" width="640" height="640"/>
</tileset>
